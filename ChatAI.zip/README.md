# ChatBot
This an intro to AI project where we use fuzzy logic and Ngrams to build a simple chatbot
## To-Do
- [X] Make fuzzy context identifier
- [X] Make matches function using ngrams
- [X] Make functions to fetch and process facts
- [ ] Train the bot
- [ ] Extra, attach it to a telegram bot
